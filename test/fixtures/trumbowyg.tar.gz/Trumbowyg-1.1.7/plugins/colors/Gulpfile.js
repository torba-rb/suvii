var gulp = require('gulp'),
    $ = require('gulp-load-plugins')(),
    path = require('path'),
    spritesmith = require('gulp.spritesmith');

var paths = {
    sprites: {
        'icons': 'ui/images/icons/**.png',
        'icons-2x': 'ui/images/icons-2x/**.png'
    },
    mainStyle: 'ui/sass/trumbowyg.colors.scss',
    styles: {
        sass: 'ui/sass',
        includePaths: ['ui/sass', '../../src/ui/sass/mixins']
    }
};

var pkg = require('../../package.json');
var banner = ['/**',
    ' * <%= pkg.title %> v<%= pkg.version %> - <%= pkg.description %>',
    ' * <%= description %>',
    ' * ------------------------',
    ' * @link <%= pkg.homepage %>',
    ' * @license <%= pkg.license %>',
    ' * @author <%= pkg.author.name %>',
    ' *         Twitter : @AlexandreDemode',
    ' *         Website : <%= pkg.author.url.replace("http://", "") %>',
    ' */',
    '\n'].join('\n');
var bannerLight = ['/** <%= pkg.title %> v<%= pkg.version %> - <%= pkg.description %>',
    ' - <%= pkg.homepage.replace("http://", "") %>',
    ' - License <%= pkg.license %>',
    ' - Author : <%= pkg.author.name %>',
    ' / <%= pkg.author.url.replace("http://", "") %>',
    ' */',
    '\n'].join('');



gulp.task('sprites', function(){
    return makeSprite() && makeSprite('-2x');
});
function makeSprite(resolution){
    if(!resolution)
        resolution = '';

    var sprite = gulp.src(paths.sprites['icons' + resolution])
        .pipe(spritesmith({
            imgName: 'icons' + resolution + '.png',
            cssName: '_sprite' + resolution + '.scss',
            cssTemplate: function(params){
                var output = '', e;
                for(var i in params.items){
                    e = params.items[i];
                    output += '$' + e.name + resolution + ': ' + e.px.offset_x + ' ' + e.px.offset_y + ';\n';
                }
                if(params.items.length > 0){
                    output += '\n\n';
                    output += '$sprite-height' + resolution + ': ' + params.items[0].px.total_height + ';\n';
                    output += '$sprite-width' + resolution + ': ' + params.items[0].px.total_width + ';\n';
                    output += '$icons' + resolution + ': "./images/icons' + resolution + '.png";';
                }

                return output;
            }
        }));
    sprite.img.pipe(gulp.dest('../../dist/plugins/colors/ui/images/'));
    sprite.css.pipe(gulp.dest(paths.styles.sass));
    return sprite.css;
}



gulp.task("styles", ["sprites"], function(){
  return gulp.src(paths.mainStyle)
    .pipe($.sass({
      sass: paths.styles.sass,
      includePaths: paths.styles.includePaths
    }))
    .pipe($.autoprefixer(["last 1 version", "> 1%", "ff >= 20", "ie >= 8", "opera >= 12", "Android >= 2.2"], { cascade: true }))
    .pipe($.header(banner, { pkg: pkg, description: "Colors plugin stylesheet for Trumbowyg editor" }))
    .pipe(gulp.dest("../../dist/plugins/colors/ui/"))
    .pipe($.size({ title: "trumbowyg.colors.css" }))
    .pipe($.rename({ suffix: ".min" })) // génère une version minimifié
    .pipe($.minifyCss())
    .pipe($.header(bannerLight, { pkg: pkg }))
    .pipe(gulp.dest("../../dist/plugins/colors/ui/"))
    .pipe($.size({ title: "trumbowyg.colors.min.css" }));
});



gulp.task('watch', function(){
    gulp.watch(paths.mainStyle, ['styles']);
});



gulp.task('build', ['styles']);

gulp.task('default', ['build', 'watch']);