# Trumbowyg WYSIWYG Editor

Trumbowyg is a simple and lightweight WYSIWYG editor, is only 15kB for faster page loading.


# Website

http://alex-d.github.io/Trumbowyg/


# Documentation

http://alex-d.github.io/Trumbowyg/documentation.html


# Contribute

You can contribute to Trumbowyg with translations in languages you know.
Thanks to `node` and `gulp`, you can improve core script, style or icons easily.


# Thanks

Vinz, who has make some icons for default design.


# License

This project is under MIT license. See LICENSE file for details.